/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruiznevadoex01;

import java.util.Scanner;

/**
 *
 * @author Raul Ruiz
 */
public class RuizNevadoEx01 {
        
    static int NUMLENGUAJES = 7;
    static int [] programadores;
    static String [] lenguajes;
    
    public static void main(String[] args) {
       
        int opt;
        
        boolean exit = false;
        
        String [] lenguajes = new String [NUMLENGUAJES];
        
        lenguajes [0] = "Java";
        lenguajes [1] = "C#";
        lenguajes [2] = "Android";
        lenguajes [3] = "HTML";
        lenguajes [4] = "CSS";
        lenguajes [5] = "Kotlin";
        lenguajes [6] = "PHP";

        int [] programadores = new int [NUMLENGUAJES];
        programadores [0] = 9522212;
        programadores [1] = 5960159;
        programadores [2] = 2397007;
        programadores [3] = 6555949;
        programadores [4] = 1080285;
        programadores [5] = 1877815;
        programadores [6] = 8401392;
        
        do {
            
            System.out.println("MENU PRINCIPAL:\n1- Mostrar lenguajes\n2- Modificar posición a partir del nombre\n" +
            "3- Mostrar máximo, mínimo y media de todos los datos\n4- Rellenar desde cero \n5- Ordenar por nombre\n" +
            "0- Salir");
            
            opt = new Scanner(System.in).nextInt();
            
            if (opt < 0 || opt > 5) {
                System.out.println("Valor erróneo, introduzca de nuevo");
            }
            else {
               switch (opt) {
                case 0:
                    exit = true;    //variable booleana en true para salir del programa
                    break;
                case 1:
                    System.out.println("Lenguaje | Programadores");
                    System.out.println("");
                        for (int i = 0; i < NUMLENGUAJES; i++) {                    //bucle que muestra todos los lenguajes de programacion y sus respectivos programadores
                            System.out.println(lenguajes[i] + "  tiene  "
                            + + programadores[i] + " programadores");
                        }
                    System.out.println("");
                    break;
                case 2:    
                    System.out.println("--Modificador de datos--\n"
                    + "No");
                    
                    break;
                case 3:
                    System.out.println("--Maximo, minimo y media de los datos--");
                    System.out.println("");
                    System.out.println("El lenguaje con mas programadores es " + lenguajes[maxProgramadores()]);        //muestra el lenguaje de programacion mas popular y la cantidad de programadores que tiene
                    System.out.println("");
                    break;
                default:
                    throw new AssertionError();
                } 
            }
            
            
        } while (exit == false);
        
    }
    
    static int maxProgramadores(){
        
        int maximo = 0;
        int lenguajePop = 0;
        
        for (int i = 0; i < NUMLENGUAJES; i++) {
            
            if (programadores [i] >= maximo) {       //si el valor de programadores [i] es mayor a 0 (la primera vez) el valor maximo pasa a ser el de este, sino pasa al siguiente.
                
                maximo = programadores [i];
                lenguajePop = i;
            }
        }
        return lenguajePop;
    }
}
